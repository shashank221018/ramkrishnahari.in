<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="icon" type="image/png" href="assets/images/favicon.png">
  
  <title>Ramkrishnahari Enterprises</title>
  <meta name="description" content="Hare Rama Krishna Enterprises Logistic company.">
  
  <!-- Bootstrap core CSS -->
  <!-- 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  
  <!-- Custom styles for this template -->
  <link href="assets/css/scrolling-nav.css" rel="stylesheet">
  
</head>
<body id="page-top">  

<div class="sticky-top py-3 bg-orange text-white shadow-sm">
<div class="container text-center fw-600 font-25">Ramkrishnahari Enterprises</div>
</div>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-light static-top shadow-sm" id="mainNav">
<div class="container">
    <a class="navbar-brand js-scroll-trigger" href="index.php" id="logo">
	<!-- <h2 class="fw-600 text-dark">SVSS</h2> -->
    <img src="assets/images/ramkrishnahari-logo.jpg" alt="">
    </a>
	
    <button class="navbar-toggler bg-secondary1 mr-2" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
    <span class="fa fa-bars"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">
    <ul class="navbar-nav ml-auto">

      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="about.php">About Us</a>
      </li>

		<li class="nav-item dropdown">
		  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		  Services</a>
			 <div class="dropdown-menu dropdown-menu-left text-left" aria-labelledby="navbarDropdown">
			 <a class="dropdown-item" href="ecommerce-products.php">Delivery of E-Commerce Products</a>
			 <a class="dropdown-item" href="grocery-products.php">Delivery of Grocery Products</a>
			 <a class="dropdown-item" href="food-beverage-products.php">Delivery of Food & Beverage Products</a>
			 <a class="dropdown-item" href="tiffin-suppliers.php">Tiffin Suppliers</a>
			 <a class="dropdown-item" href="customized-delivery.php">Customized Delivery Services</a>
			 </div>
		</li>

      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="career.php">Career</a>
      </li>
      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="job-request.php">Apply for Job</a>
      </li>
      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="contact.php">Contact Us</a>
      </li>
          
	</ul>	
    </div>	  	  

</div>
</nav>
<div class="subheader">
	<div class="container">
		<a href="index.php" class="text-dark"><i class="fa fa-home"></i> Home </a> | Job Application
	</div>
</div>


<!-- Page Content -->
<section class="bg-info text-white">	
<div class="container">	
<div class="row">
	<div class="col-md-12 text-center">
	<h1>Join Logistics Company and Earn 15K to 40K per month</h1>
	<h4>Work for top brands in India</h4>
	</div>

</div>
</div>
</section>


<section>
<div class="container">
	<div class="row">
				
		<div class="col-md-8 col-md-offset-2">
        <div class="content">
		
        <form name="apply_signup" action="job-request-action.php" method="POST" enctype="multipart/form-data">
		
        <table class="table table-bordered table-hover">		
        <h3>SELECT AREA OF WORK</h3>
		
		<!--
        <tr>
            <td width="150">Region</td>
            <td>
            <select name="region" class="form-control">
			<option value="0"> Select Region </option>
						
			</select>	
            </td>
        </tr>		
		-->
		
        <tr>
            <td width="150">Area / Hub</td>
            <td>
            <select name="hub_id" class="form-control">
			<option value="0"> Select Area / Hub </option>
			<option value='158'>AdampurHub_ADA</option><option value='168'>AdityapurHub_IXW</option><option value='450'>AgartalaHub_IXA</option><option value='569'>AHMADPUR</option><option value='253'>AhmadpurHub_AHM</option><option value='254'>AhmedNagarHub_AHN</option><option value='528'>AhmedNagarHub_AHN</option><option value='187'>AirportblrHub_BLR</option><option value='367'>AizawlHub_AJL</option><option value='156'>AjwaHub_BDQ</option><option value='255'>AkolaHub_AKD</option><option value='529'>AkolaHub_AKD</option><option value='116'>AkotaHub_BDQ1</option><option value='117'>AkotaHub_BDQ2</option><option value='305'>AlibagHub_ABG</option><option value='599'>AlibagHub_ABG</option><option value='461'>AliganjHub_LKO</option><option value='76'>AlipurHub_DEL</option><option value='452'>AllahabadHub_ALD</option><option value='1'>AmalapuramHub_AMP</option><option value='256'>AmbajogaiHub_AOI</option><option value='550'>AmbajogaiHub_AOI</option><option value='362'>AMBEGAON</option><option value='410'>AmijikaraiHub_CHN</option><option value='573'>AmravatiHub_AMI</option><option value='118'>AnandHub_AMD1</option><option value='109'>AnandHub_AMD2</option><option value='469'>AndalHub_DGP</option><option value='265'>AndheriHub_MUM</option><option value='279'>AndheriHub_MUM1</option><option value='280'>AndheriHub_MUM2</option><option value='268'>AndheriWestHub_MUM</option><option value='373'>AngulHub_ANG</option><option value='470'>ArambaghHub_AMB</option><option value='471'>AsansolHub_ASN</option><option value='600'>AshokNagarHub_AKN</option><option value='518'>AsikaHub_CAP</option><option value='560'>ATPADI</option><option value='48'>AurangabadBiharHub_AWB</option><option value='522'>AurangabadHub_IXU</option><option value='417'>AvinashiRdHub_CJB</option><option value='308'>BadlapurHub_BAP</option><option value='49'>BakhriHub_BKH</option><option value='236'>BALAGHAT</option><option value='212'>BalaghatHub_BGT</option><option value='179'>BanashankariHub_BLR</option><option value='478'>BandelHub_BND</option><option value='332'>BanerHub_Pune</option><option value='352'>BanerHub_Pune1</option><option value='348'>BanerHub_Pune2</option><option value='95'>BapunagarHub_AMD</option><option value='571'>BaramatiHub_BRM</option><option value='503'>BarasatHub_KOL</option><option value='502'>BarrackporeHub_KOL</option><option value='435'>BasheerBaghHub_HYD</option><option value='555'>BASMATH</option><option value='97'>BavlaHub_AMD</option><option value='565'>BEED</option><option value='574'>BeedHub_BED</option><option value='439'>BegumPetHub_HYD</option><option value='190'>BegurHub_BLR</option><option value='496'>BehalaHub_KOL</option><option value='497'>BelghariaHub_KOL</option><option value='178'>Bellandurhub_BLR</option><option value='593'>BenipurHub_BPA</option><option value='374'>BerhampurHub_BMP</option><option value='51'>BettiahHub_BTH</option><option value='233'>BetulHub_BTL</option><option value='195'>BhadravathiHub_BVT</option><option value='551'>BhandaraHub_BHR</option><option value='271'>BhandupHub_MUM</option><option value='99'>BharuchHub_BRH</option><option value='139'>BharuchHub_BRH1</option><option value='597'>BhataniHub_BHA</option><option value='100'>BhavnagarHub_BVG</option><option value='110'>BhavnagarHub_BVG</option><option value='498'>BhawanipurHub_KOL</option><option value='65'>BhilaiHub_BIA</option><option value='237'>BHIND</option><option value='392'>BhiwadiHub_DHR</option><option value='313'>BhiwandiHub_BHI</option><option value='580'>BHOKAR</option><option value='562'>BHOKARDAN</option><option value='424'>BhongirHub_BNG</option><option value='334'>BhosariHub_PUNE</option><option value='346'>BhosariHub_PUNE</option><option value='376'>BhubaneswarHub_BBI</option><option value='101'>BhujHub_BHJ</option><option value='140'>BhujHub_BHJ</option><option value='52'>BiharSharifHub_BSF</option><option value='196'>BijapurHub_BJR</option><option value='391'>BikanerHub_BKB</option><option value='601'>BinaHub_BIN</option><option value='50'>Bishalgarh1Hub_BGH</option><option value='473'>BishnupurHub_VSU</option><option value='18'>BiswanathCharialiHub_VNE</option><option value='171'>BITMesraHub_IXR</option><option value='7'>BiwiNagarHub_NLR</option><option value='309'>BkcHub_MUM1</option><option value='298'>BOISAR</option><option value='258'>BoisarHub_BIS</option><option value='163'>BokaroHub_BKO</option><option value='474'>BongaonHub_KOL</option><option value='136'>Bopal Hub</option><option value='293'>BoriviliHub_MUM1</option><option value='317'>BoriviliHub_MUM_PL</option><option value='292'>Boriviliwest_Mum</option><option value='519'>BugudaHub_GAM</option><option value='602'>BuldhanaHub_BLD</option><option value='235'>BURHANPUR</option><option value='583'>CABTMaharajganjODH_MGJ</option><option value='19'>CacharHub_IXS</option><option value='92'>CanaconaHub_GOA</option><option value='98'>CGRoadHub_ADI</option><option value='104'>CGRoadHub_ADI1</option><option value='111'>CGRoadHub_ADI2</option><option value='164'>ChaibasaHub_CBS</option><option value='335'>ChakanHub_PUNE</option><option value='359'>ChakanHub_PUNE</option><option value='476'>ChanchalHub_CHC</option><option value='477'>ChandannagarHub_CNR</option><option value='388'>ChandigarhRoadHub_LUH</option><option value='11'>ChandragiriHub_TPT</option><option value='479'>ChandrakonaHub_CDR</option><option value='547'>CHANDRAPUR</option><option value='375'>ChandraSekharpurHub_BBI</option><option value='578'>CHANDWAD</option><option value='325'>CharaiHub_MUM</option><option value='459'>ChaukHub_LKO</option><option value='272'>ChemburHub_MUM1</option><option value='281'>ChemburHub_MUM2</option><option value='423'>ChengalpattuHub_CHN</option><option value='250'>CHHATARPUR</option><option value='379'>ChhatrapurHub_CAP</option><option value='231'>ChhindwaraHub_CHH</option><option value='603'>ChikhliHub_ROM</option><option value='495'>ChinarParkHub_KOL</option><option value='215'>CityCenterHub_GWL</option><option value='219'>CityCenterHub_GWL</option><option value='323'>CollegeRoadHub_NSK</option><option value='530'>CollegeRoadHub_NSK</option><option value='516'>ConnectIndiaNewTownODH_KOL</option><option value='480'>CoochBeharHub_COB</option><option value='257'>CornerRoadHub_IXU</option><option value='531'>CornerRoadHub_IXU</option><option value='380'>CuttackHub_BBI</option><option value='604'>DabraHub_DAB</option><option value='269'>DadarWestHub_MUM</option><option value='134'>Dahej</option><option value='234'>DAMOH</option><option value='53'>DanapurHub_DNR</option><option value='54'>DarbhangaHub_DBG</option><option value='481'>DarjeelingHub_DAI</option><option value='71'>daryaganjhub_DEL</option><option value='598'>DeglurHub_DGL</option><option value='447'>DependoNizampetODH_HYD</option><option value='517'>DependoTollygunjODH_KOL</option><option value='475'>DewandighiHub_BDM</option><option value='228'>DEWAS</option><option value='165'>DhanbadHub_DBD</option><option value='330'>DhankawadiHub_PUNE</option><option value='347'>DhankawadiHub_PUNE1</option><option value='342'>DhankawadiHub_PUNE2</option><option value='197'>DharwadHub_HBX</option><option value='381'>DhenkanalHub_DNK</option><option value='532'>DhuleHub_DHL</option><option value='506'>DiamondHarbourHub_KOL</option><option value='20'>DibrugarhHub_DIB</option><option value='432'>DomalgudaHub_HYD</option><option value='263'>DombivliHub_MUM</option><option value='310'>DombivliHub_MUM</option><option value='181'>DomlurHub_BLR</option><option value='21'>DudhnoiHub_DNI</option><option value='22'>DuliajanHub_DLN</option><option value='482'>DurgapurHub_DGP</option><option value='138'>DWARKA</option><option value='102'>DwarkaGujaratHub_DWK</option><option value='428'>ECILHub_HYD</option><option value='180'>EcityHub_BLR</option><option value='209'>ElamakkaraHub_COK</option><option value='17'>ElasticRunFancyBazaarODH_GAU</option><option value='507'>EnglishBazarHub_LDA</option><option value='453'>FaizabadHub_FZB</option><option value='483'>FarrakaHub_NFK</option><option value='299'>FortHub_MUM1</option><option value='273'>FortHub_MUM2</option><option value='605'>GadarwaraHub_GAD</option><option value='579'>GADCHIROLI</option><option value='14'>GajuwakaHub_VTZ</option><option value='105'>GandhidhamHub_GDM</option><option value='106'>GandhiNagarHub_GAN</option><option value='606'>GangakhedHub_GKD</option><option value='174'>GanganagarHub_BLR</option><option value='594'>GanganiHub_GNN</option><option value='204'>Gardencityhub_MYS</option><option value='494'>GariaHub_KOL</option><option value='378'>GautamnagarHub_BBI</option><option value='55'>GayaHub_GAY</option><option value='270'>GhansoliHub_MUM</option><option value='274'>GhansoliHub_MUM1</option><option value='300'>GhansoliHub_MUM2</option><option value='275'>GhatkoparHub_MUM1</option><option value='276'>GhatkoparHub_MUM2</option><option value='288'>GhodbunderHub_MUM</option><option value='23'>GoalparaHub_GLP</option><option value='135'>GodhraHub_GHR</option><option value='24'>GolaghatHub_GLG</option><option value='454'>GondaHub_GND</option><option value='131'>Gondal</option><option value='588'>GopiballavpurHub_MDN</option><option value='266'>GoregaonHub_MUM</option><option value='277'>GoregaonHub_MUM1</option><option value='282'>GoregaonHub_MUM2</option><option value='74'>GreaterNoidaHub_DEL</option><option value='2'>GudiwadaHub_GDV</option><option value='198'>GulbargaHub_GUL</option><option value='166'>GumlaHub_GMA</option><option value='232'>GunaHub_GUN</option><option value='484'>GurapHub_GRA</option><option value='386'>GurdaspurHub_GDS</option><option value='72'>GurgaonHub_DEL</option><option value='214'>GwaliorHub_GWL</option><option value='485'>HabraHub_KOL</option><option value='425'>HabsigudaHub_HYD</option><option value='338'>HadapsarHub_PUNE</option><option value='343'>HadapsarHub_PUNE1</option><option value='356'>hadapsarHub_PUNE1</option><option value='28'>HaflongHub_LFG</option><option value='58'>HajiGanjHub_PAT</option><option value='56'>HajipurHub_HJP</option><option value='448'>HanamkondaHub_WGL</option><option value='607'>HardaHub_HAR</option><option value='608'>HarijHub_HRJ</option><option value='626'>HarinaviHub_KOL</option><option value='172'>HarmuHub_IXR</option><option value='457'>HathrasHub_HTH</option><option value='123'>HIMATNAGAR</option><option value='557'>HingoliHub_HIN</option><option value='429'>HitechCityHub_HYD</option><option value='29'>HojaiHub_HJI</option><option value='227'>HOSHANGABAD</option><option value='387'>HoshiarpurHub_HAP</option><option value='492'>HowrahHub_KOL</option><option value='175'>HSRHub_BLR</option><option value='191'>HSRHub_BLR</option><option value='199'>HubliHub_HBX</option><option value='193'>HulimavuHub_BLR</option><option value='242'>HuzurHub_HUU</option><option value='259'>IchalkaranjiHub_KHL</option><option value='575'>IchalkaranjiHub_KHL</option><option value='549'>IndapurHub_IND</option><option value='216'>IndoreHub_IDR</option><option value='218'>IndoreHub_IDR1</option><option value='226'>IndoreHub_IDR2</option><option value='609'>ItarsiHub_ITR</option><option value='182'>ITPLHub_BLR</option><option value='222'>JabalpurHub_JBL</option><option value='243'>JabalpurHub_JBL</option><option value='595'>JagitiyalHub_JGL</option><option value='394'>JaipurHub_JAI</option><option value='520'>JaleswarHub_JER</option><option value='538'>JalgaonHub_JGO1</option><option value='533'>JalgaonHub_JGO2</option><option value='572'>JalnaHub_JLN</option><option value='486'>JalpaiguriHub_JPG</option><option value='625'>JamdoliHub_JAM</option><option value='141'>JamnagarHub_QGR</option><option value='167'>JamshedpurHub_IXW</option><option value='129'>JASDAN</option><option value='203'>JaydevNagarHub_MYS</option><option value='355'>JejuriHub_JEJ</option><option value='487'>JhargramHub_JGM</option><option value='169'>JhariaHub_DBD</option><option value='159'>JindHub_JND</option><option value='30'>JorhatHub_JRH</option><option value='127'>JunagadhHub_IXK</option><option value='152'>JunagadhHub_IXK</option><option value='260'>JunnarHub_JNN</option><option value='556'>JunnarHub_JNN</option><option value='4'>KadapaHub_KDP</option><option value='563'>KALAMB</option><option value='137'>Kalawad hub</option><option value='142'>KalawadRoadHub_RAJ</option><option value='289'>KalyanDombivliHub_New1</option><option value='283'>KalyanHub_MUM</option><option value='318'>Kalyanhub_MUM_PL</option><option value='501'>KalyaniHub_KOL</option><option value='189'>KalyanNagarHub_BLR</option><option value='440'>KamareddyHub_KMC</option><option value='294'>KandivaliHub_MUM2</option><option value='59'>KankarBaghHub_PAT</option><option value='170'>KankeHub_IXR</option><option value='552'>KannadHub_KNN</option><option value='208'>KannurHub_KAN</option><option value='558'>KaradHub_KRD</option><option value='441'>KarimnagarHub_KMN</option><option value='73'>KarolBaghHub_DEL</option><option value='213'>KarondHub_BHO</option><option value='223'>KarondHub_BHO</option><option value='468'>KashipurHub_KAS</option><option value='229'>KATNI</option><option value='217'>KatniHub_KTN</option><option value='426'>KavuriHillsHub_HYD</option><option value='408'>KeelkattalaiHub_CHN</option><option value='132'>KHAMBHALIA</option><option value='377'>KhandagiriHub_BBI</option><option value='488'>Kharagpurhub_KGP</option><option value='284'>KhargharHub_MUM1</option><option value='291'>KhargharHub_MUM2</option><option value='576'>KhopoliHub_KPL</option><option value='490'>KhoyrasoleHub_BMG</option><option value='411'>KKNagarHub_CHN</option><option value='205'>KochiHub_COK</option><option value='437'>KokapetHub_HYD</option><option value='173'>KokarHub_IXR</option><option value='523'>KolhapurHub_KHL</option><option value='431'>KondapurHub_HYD</option><option value='370'>KoorieeBerhampurODH_BMP</option><option value='368'>KoorieeBhubaneswarODH_BBI</option><option value='369'>KoorieeGautamnagarODH_BBI</option><option value='201'>KoorieeHarohalliODH_BLR</option><option value='371'>KoorieeKhurdaODH_KUD</option><option value='200'>KoorieeSoukyaRdODH_BLR</option><option value='542'>KOPARGAON</option><option value='395'>KotaHub_KTU</option><option value='416'>KovaipudurHub_KVP</option><option value='176'>KRPuramHub_BLR</option><option value='624'>KukasHub_KUK</option><option value='430'>KukatpallyHub_HYD</option><option value='202'>Kundapurhub_KPR</option><option value='5'>KuppamHub_KPM</option><option value='160'>KurukshetraHub_KUR</option><option value='504'>LakeTownHub_KOL</option><option value='186'>LakeViewHub_BLR</option><option value='589'>LalganjHub_LLG</option><option value='128'>LalparHub_LLP</option><option value='31'>LankaHub_LKA</option><option value='261'>LaturHub_LTU</option><option value='521'>LaturHub_LTU</option><option value='434'>LBNagarHub_HYD</option><option value='596'>LemoorHub_LMR</option><option value='610'>Lonandhub_LND</option><option value='32'>LumdingHub_LMG</option><option value='427'>MadinagudaHub_HYD</option><option value='567'>MAHAD</option><option value='184'>Mahadevapura_BLR</option><option value='267'>MaladWestHub_MUM</option><option value='543'>MALEGAON</option><option value='25'>MaligaonHub_GAU</option><option value='592'>MalviyaNagarhub_JAI</option><option value='94'>ManiNagarHub_ADI</option><option value='119'>ManiNagarHub_ADI1</option><option value='120'>ManiNagarHub_ADI2</option><option value='148'>ManiNagarHub_ADI_PL</option><option value='33'>MargheritaHub_MRG</option><option value='512'>MatigaraHub_IXB</option><option value='78'>MayurViharHub_DEL</option><option value='414'>MedavakkamHub_CHN</option><option value='436'>MedchalHub_HYD</option><option value='455'>MedicalRoadHub_GOP</option><option value='611'>MehakrHub_MKR</option><option value='125'>MehsanaHub_MHN</option><option value='153'>MehsanaHub_MHN</option><option value='80'>MercesHub_GOA</option><option value='88'>MercesHub_GOA</option><option value='442'>MetpallyHub_MTP</option><option value='489'>MidnaporeHub_MDN</option><option value='311'>MiraRoadHub_MUM</option><option value='319'>MiraRoadHub_MUM_PL</option><option value='623'>MogaHub_MOG</option><option value='385'>MohaliHub_IXC</option><option value='449'>MoloyNagarHub_IXA</option><option value='34'>MoranhatHub_MRH</option><option value='143'>MorbiHub_MRB</option><option value='245'>MORENA</option><option value='508'>MorgramHub_MGA</option><option value='133'>MOTIKHAVDI</option><option value='154'>MotikhavdiHub_MKH</option><option value='144'>MundraHub_MUD</option><option value='584'>MuraraiHub_MRR</option><option value='472'>MurshidabadHub_MBB</option><option value='612'>MurtizapurHub_MTZ</option><option value='462'>MuzaffarnagarHub_MFN</option><option value='57'>MuzaffarpurHub_MZF</option><option value='35'>NagaonHub_NGN</option><option value='339'>NagarRoadHub_PUNE</option><option value='341'>NagarRoadHub_PUNE1</option><option value='349'>NagarRoadHub_PUNE2</option><option value='36'>NaharkatiyaHub_NHK</option><option value='16'>NaharlagunHub_NHL</option><option value='37'>NalbariHub_NLV</option><option value='443'>NalgondaHub_NGD</option><option value='524'>NandedHub_NDC</option><option value='613'>NandurbarHub_NND</option><option value='6'>NarasaraopetHub_NRT</option><option value='614'>NarkhedHub_NKD</option><option value='534'>NashikHub_NSK</option><option value='535'>NashikHub_NSK_New</option><option value='82'>NavelimHub_GOA</option><option value='107'>NavsariHub_STV1</option><option value='615'>NeemuchHub_NEE</option><option value='566'>NEWASA</option><option value='329'>NIBMHub_PUNE</option><option value='590'>NidadavoleHub_RJY</option><option value='327'>NigadiHub_PUNE</option><option value='616'>NilangaHub_NLN</option><option value='444'>NimapadaHub_NMP</option><option value='445'>NirmalHub_NML</option><option value='446'>NizamabadHub_NZB</option><option value='463'>NoidaHub_DEL</option><option value='38'>NoonmatiHub_GAU</option><option value='540'>OSMANABAD</option><option value='413'>PadiHub_CHN</option><option value='559'>PAITHAN</option><option value='145'>PalanpurHub_PLN</option><option value='306'>PalgharHub_PAR</option><option value='509'>PanchanandapurHub_PCD</option><option value='322'>PanchavatiHub_NSK</option><option value='161'>PanchkulaHub_PKL</option><option value='617'>PandharpurHub_PDH</option><option value='382'>PanikoiliHub_JJK</option><option value='79'>PanjimHub_GOA</option><option value='90'>PanjimHub_GOA1</option><option value='84'>PanjimHub_GOA2</option><option value='89'>PanjimHub_GOA3</option><option value='307'>PanvelHub_PNV</option><option value='324'>PanvelHub_PNV</option><option value='541'>PARBHANI</option><option value='108'>ParvatPatiyaHub_STV</option><option value='389'>PatialaHub_PTA</option><option value='194'>PeenyaHub_BLR</option><option value='75'>Peeragarhi_PRG</option><option value='585'>PekhamBansiODH_BNS</option><option value='582'>PekhamPadraunaODH_PDR</option><option value='390'>PhagwaraHub_PGR</option><option value='70'>Phase3NoidaHub_DEL</option><option value='500'>PhooltalaHub_KOL</option><option value='328'>PimpriHub_PUNE</option><option value='360'>PimpriHub_PUNE1</option><option value='393'>PinkCityHub_JAI</option><option value='69'>Pitampurahub_DEL</option><option value='86'>PondaHub_PND1</option><option value='146'>PorbandarHub_POR</option><option value='83'>PorvorimHub_GOA</option><option value='337'>PrabhatRoadHub_PUNE</option><option value='340'>PrabhatRoadHub_PUNE1</option><option value='350'>PrabhatRoadHub_PUNE2</option><option value='62'>PurniaHub_PRN</option><option value='510'>PuruliaHub_PRR</option><option value='553'>PusadHub_PSD</option><option value='8'>PutturHub_PUT</option><option value='130'>RADHANPUR</option><option value='67'>RaipurHub_RPR</option><option value='60'>RajabazarHub_PAT</option><option value='9'>RajahmundryHub_RJY</option><option value='177'>RajajinagarHub_BLR</option><option value='220'>RajendraNagarHub_IDR1</option><option value='246'>RajendraNagarHub_IDR1</option><option value='357'>RAJGURUNAGAR</option><option value='61'>RajivNagarHub_PAT</option><option value='511'>RanaghatHub_RHA</option><option value='96'>RanipHub_AMD</option><option value='354'>Ranjangaon</option><option value='363'>RanjangaonHub_RJN</option><option value='66'>RatanpurHub_PAB</option><option value='230'>RATLAM</option><option value='251'>RatlamHub_RTM</option><option value='545'>RATNAGIRI</option><option value='383'>RayagadaHub_RGD</option><option value='247'>RewaHub_RWA</option><option value='467'>RingRoadHub_DED</option><option value='456'>RishikeshHub_HRD</option><option value='365'>RJSCImphalODH_IMP</option><option value='564'>ROHA</option><option value='384'>RourkelaHub_RRK</option><option value='415'>RoyapuramHub_CHN</option><option value='192'>RTNagarHub_BLR</option><option value='248'>SagarHub_SGR</option><option value='464'>SaharanpurHub_SHP</option><option value='465'>SahjanwaHub_SHJ</option><option value='505'>SakherBazarHub_KOL</option><option value='290'>SakinakaHub_MUM1</option><option value='314'>Sakinakahub_MUM_PL</option><option value='491'>SalkiaHub_KOL</option><option value='493'>SaltlakeHub_KOL</option><option value='433'>SanathNagarHub_HYD</option><option value='586'>SandalPurHub_PAT</option><option value='548'>SangamnerHub_SGM</option><option value='525'>SangliHub_SNG1</option><option value='526'>SangliHub_SNG2</option><option value='93'>SanquelimHub_GOA</option><option value='295'>SantacruzHub_MUM1</option><option value='301'>SantacruzHub_MUM2</option><option value='81'>SanvordemHub_GOA</option><option value='85'>SanvordemHub_GOA</option><option value='12'>SapthagiriHub_TPT</option><option value='150'>Sarolihub_STV_PL</option><option value='39'>SarupatharHub_SZR</option><option value='63'>SasaramHub_SSM</option><option value='577'>SataraHub_STR</option><option value='249'>SatnaHub_STA</option><option value='238'>SEONI</option><option value='264'>SewriHub_MUM</option><option value='296'>SewriHub_MUM1</option><option value='262'>ShadowFaxVishrantwadiODH_PUNE</option><option value='561'>SHAHADA</option><option value='239'>SHAHDOL</option><option value='618'>ShegaonHub_SGO</option><option value='366'>ShillongHub_SHL</option><option value='333'>ShivajinagarHub_PUNE</option><option value='244'>SHIVPURI</option><option value='409'>ShollinganallurHub_CHN</option><option value='619'>ShrirampurHub_SMP</option><option value='151'>Shyamalhub_SHY_PL</option><option value='587'>ShyamnagarHub_KOL</option><option value='40'>SibsagarHub_SBS</option><option value='241'>SidhiHub_SID</option><option value='466'>SigraHub_VNS</option><option value='225'>SingrauliHub_SGU</option><option value='513'>SingurHub_SIU</option><option value='3'>SitaramNagarHub_GTR</option><option value='64'>SiwanHub_SWN</option><option value='27'>SixMileHub_GAU</option><option value='499'>SodepurHub_KOL</option><option value='364'>SolapurHub_SSE</option><option value='539'>SolapurHub_SSE</option><option value='331'>SomatanePhataHub_PUNE</option><option value='353'>SomatanePhataHub_PUNE</option><option value='126'>SOMNATH</option><option value='121'>SosyoCircleHub_STV</option><option value='10'>SrikalahastiHub_SKH</option><option value='183'>SrinagarKAHub_BLR</option><option value='112'>SuratHub_STV</option><option value='149'>SuratHub_STV_PL</option><option value='147'>SurendraNagarHub_SDR</option><option value='155'>SurendraNagarHub_SDR</option><option value='372'>TalcherHub_TLH</option><option value='351'>TALEGAON</option><option value='620'>TalodHub_TLD</option><option value='514'>TamlukHub_TMZ</option><option value='278'>TardeoHub_MUM1</option><option value='581'>Teliamura1Hub_TLR</option><option value='419'>TempleCityHub_IXM</option><option value='41'>TezpurHub_TZR</option><option value='206'>ThalasseryHub_THL</option><option value='207'>ThaliparambaHub_KAN</option><option value='285'>ThaneHub_MUM1</option><option value='302'>ThaneHub_MUM2</option><option value='344'>ThergaonHub_Pune1</option><option value='345'>ThergaonHub_Pune2</option><option value='412'>ThirumullaivoyalHub_CHN</option><option value='420'>ThirunelveliHub_TVL</option><option value='42'>TinsukiaHub_TSK</option><option value='421'>TirupurHub_TPR</option><option value='210'>TiruvallaHub_TIR</option><option value='591'>TopsiaHub_KOL</option><option value='460'>TransportNagarHub_LKO</option><option value='438'>TrimulgherryHub_HYD</option><option value='321'>TrimurtiNagarHub_NAG</option><option value='536'>TrimurtiNagarHub_NAG</option><option value='396'>TumkurHub_TKR</option><option value='568'>TUMSAR</option><option value='399'>TuticorinHub_TUT</option><option value='451'>UdaipurTripuraHub_IXR</option><option value='554'>UdgirHub_UDG</option><option value='400'>UdumalpetHub_UDM</option><option value='221'>UjjainHub_UJN</option><option value='252'>UjjainHub_UJN</option><option value='26'>UlubariHub_GAU</option><option value='515'>UluberiaHub_ULB</option><option value='124'>UnaHub_UNA</option><option value='304'>URAN</option><option value='401'>UtangaraiHub_UTN</option><option value='211'>VadakaraHub_VRA</option><option value='398'>VadavalliHub_CJB</option><option value='418'>VadavalliHub_CJB</option><option value='113'>ValsadHub_AMD</option><option value='402'>VaniyambadiHub_VNM</option><option value='157'>VapiHub_AMD</option><option value='115'>VapiHub_AMD1</option><option value='122'>VapiHub_AMD2</option><option value='297'>VasaiHub_MUM</option><option value='326'>VasaiHub_MUM</option><option value='316'>VasaiHub_MUM_PL</option><option value='77'>VasantKunjHub_DEL</option><option value='312'>VashiHub_NBM</option><option value='103'>VejalpurHub_ADI1</option><option value='114'>VejalpurHub_ADI2</option><option value='403'>VelloreHub_VLR</option><option value='422'>VelloreHub_VLR</option><option value='87'>VernaHub_GOA</option><option value='91'>VernaHub_GOA</option><option value='458'>VibhutiKhandHub_LKO</option><option value='240'>VIDISHA</option><option value='224'>VidyanagarHub_BHO1</option><option value='44'>VidyaranyapuraHub_BLR</option><option value='404'>VijayamangalamHub_VJM</option><option value='43'>VijayanagarHub_BLR</option><option value='13'>VijayawadaHub_VJA</option><option value='406'>ViluppuramHub_VEP</option><option value='405'>ViluppuramHub_VPM</option><option value='397'>VirajpetHub_VRJ</option><option value='286'>VirarHub_MUM</option><option value='407'>VirudhunagarHub_VIR</option><option value='15'>VisakhapatnamHub_VTZ</option><option value='621'>VitaHub_VTA</option><option value='622'>VyaraHub_VYR</option><option value='68'>VyasarpadiHub_CHN</option><option value='287'>WadalaHub_MUM1</option><option value='303'>WadalaHub_MUM2</option><option value='315'>WadalaHub_MUM_PL</option><option value='527'>Wadi_NAGNew1</option><option value='361'>WagholiHub_PUNE1</option><option value='544'>WARDHA</option><option value='320'>WardhamanNagar_NAG</option><option value='537'>WardhamanNagar_NAG</option><option value='336'>WarjeHub_PUNE</option><option value='358'>WarjeHub_PUNE1</option><option value='570'>WASHIM</option><option value='162'>YamunaNagarHub_YNR</option><option value='45'>YashwantpuraHub_BLR</option><option value='188'>YashwantpuraHub_BLR</option><option value='46'>YashwantpuraSplitHub_BLR</option><option value='546'>YAVATMAL</option><option value='47'>YelahankaHub_BLR</option><option value='185'>YelahankaHub_BLR</option>			
			</select>	
            </td>
        </tr>
		</table>

        <h3>Personal Details</h3>
        <table class="table table-bordered">				
        <tr>
            <td width="150">First Name</td>
            <td><input type="text" name="first_name" class="form-control"></td>
        </tr>
        <tr>
            <td>Middle Name</td>
            <td><input type="text" name="middle_name" class="form-control"></td>
        </tr>
        <tr>
            <td>Last Name</td>
            <td><input type="text" name="last_name" class="form-control"></td>
        </tr>
        
        <tr>
            <td>Gender</td>
            <td>
			<input type="radio" name="gender" value="male" checked> Male
			<input type="radio" name="gender" value="female"> Female
			</td>
        </tr>
        <tr>
            <td>DOB</td>
            <td><input type="date" name="dob" class="form-control"></td>
        </tr>
        
        </table>
        
        
        <h3>Communication Details</h3>
        <table class="table table-bordered">
        <tr>
            <td width="150">Address</td>
            <td><input type="text" name="address" class="form-control"></td>
        </tr>
        <tr>
            <td>Taluka</td>
            <td><input type="text" name="taluka" class="form-control"></td>
        </tr>
        <tr>
            <td>District</td>
            <td><input type="text" name="district" class="form-control"></td>
        </tr>
        <tr>
            <td>State</td>
            <td><input type="text" name="state" class="form-control"></td>
        </tr>
        <tr>
            <td>Pincode</td>
            <td><input type="text" name="pincode" class="form-control"></td>
        </tr>
        <tr>
            <td>Mobile</td>
            <td><input type="text" name="mobile" class="form-control"></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><input type="email" name="email" class="form-control"></td>
        </tr>
        </table>

        <input type="submit" name="apply-for-job" class="btn btn-primary" value="Submit">
        
        </form>
    </div>

		</div>
		

		
		<div class="col-md-8 col-md-offset-2">
		
			<br><h3>Instruction</h3>
			<ul style="padding-left:18px; font-size:20px; line-height:150%;">
				<li>Please fill complete form.</li>
				<li>Select Area of Work (HUB) carefully where you would like to work.</li>
				<li>Submit resume in WORD DOCUMENT or PDF File only</li>
				<li>Once application received you will be notified by official staff for next process.</li>
				<li>After confirmation you will be assigned UUSER ID & Password to login and complete profile for official records.</li>
				<li>Other process and terms and conditions will be discussed after short listing of profile.</li>
				<li>If you have any query please write to us <a href="mailto:info@ramkrishnahari.in">info@ramkrishnahari.in</a></li>
			</ul>
		</div>
 
		  
	</div>
</div>	
</section>
		
		
		
		


<!-- Footer -->
<footer class="py-5">
<div class="container">
<div class="row">

    <div class="col-md-12 mb-4"> 
		<h4>Ramkrishnahari Enterprises</h4>
		<p class="font-14">D-601, Crystal Plaza, New Link Road, Andheri (W), Mumbai - 400053.</p>
		<a href="#" class="btn btn-outline-warning"><i class="fa fa-phone"></i> +91 022 4972 9022</a>
		<a href="#" class="btn btn-outline-warning"><i class="fa fa-envelope"></i> info@rkhenterprises.co.in</a>
    </div>

    <div class="col-md-12"> 
    <p class="m-0 font-14">Copyright &copy; 2020. All rights reserved.</a></p>
  </div>

</div>
</div>
</footer>


<!-- Bootstrap core JavaScript -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<!-- Bootstrap core JavaScript -->
<!--
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
-->
  <!-- Plugin JavaScript -->
<!--  <script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script> -->

  <!-- Custom JavaScript for this theme -->
  <script src="assets/js/scrolling-nav.js"></script>
  <script src="assets/data-hover/bootstrap-hover-dropdown.js"></script>
 
</body>
</html>

<!-- Button to Open the Modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Open modal</button> -->


<!-- The Modal -->
<div class="modal fade" id="AgentLogin">
  <div class="modal-dialog modal-md">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Vendor Login</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form method="post" action="vendor/index.php">
          <div class="form-group">
            <input type="email" name="inputEmail" class="form-control" placeholder="Email">
          </div>  
          <div class="form-group">
            <input type="password" name="inputPassword" class="form-control" placeholder="Password">
          </div>  
          <div class="form-group text-center">
            <input type="submit" name="vendorLogin" class="form-control btn btn-primary mb-3" value="Login"> 
            <a class="mt-4" href="get-started.php">Not Registered</a>
          </div>  
        </form>  
      </div>

      <!-- Modal footer -->
      <!--
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
      -->
    </div>
  </div>
</div>