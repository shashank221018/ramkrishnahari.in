<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="icon" type="image/png" href="assets/images/favicon.png">
  
  <title>Ramkrishnahari Enterprises</title>
  <meta name="description" content="Hare Rama Krishna Enterprises Logistic company.">
  
  <!-- Bootstrap core CSS -->
  <!-- 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  
  <!-- Custom styles for this template -->
  <link href="assets/css/scrolling-nav.css" rel="stylesheet">
  
</head>
<body id="page-top">  

<div class="sticky-top py-3 bg-orange text-white shadow-sm">
<div class="container text-center fw-600 font-25">Ramkrishnahari Enterprises</div>
</div>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-light static-top shadow-sm" id="mainNav">
<div class="container">
    <a class="navbar-brand js-scroll-trigger" href="index.php" id="logo">
	<!-- <h2 class="fw-600 text-dark">SVSS</h2> -->
    <img src="assets/images/ramkrishnahari-logo.jpg" alt="">
    </a>
	
    <button class="navbar-toggler bg-secondary1 mr-2" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
    <span class="fa fa-bars"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">
    <ul class="navbar-nav ml-auto">

      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="about.php">About Us</a>
      </li>

		<li class="nav-item dropdown">
		  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		  Services</a>
			 <div class="dropdown-menu dropdown-menu-left text-left" aria-labelledby="navbarDropdown">
			 <a class="dropdown-item" href="ecommerce-products.php">Delivery of E-Commerce Products</a>
			 <a class="dropdown-item" href="grocery-products.php">Delivery of Grocery Products</a>
			 <a class="dropdown-item" href="food-beverage-products.php">Delivery of Food & Beverage Products</a>
			 <a class="dropdown-item" href="tiffin-suppliers.php">Tiffin Suppliers</a>
			 <a class="dropdown-item" href="customized-delivery.php">Customized Delivery Services</a>
			 </div>
		</li>

      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="career.php">Career</a>
      </li>
      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="job-request.php">Apply for Job</a>
      </li>
      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="contact.php">Contact Us</a>
      </li>
          
	</ul>	
    </div>	  	  

</div>
</nav>
<div class="subheader">
	<div class="container">
		<a href="index.php" class="text-dark"><i class="fa fa-home"></i> Home </a> | Services
	</div>
</div>

<!-- Page Content -->
<section class="bg-info text-white">	
<div class="container">	
<div class="row">	

        <div class="col-sm-6 py-3">
			<img src="assets/images/swiggy-1.png" class="img-fluid rounded">
		</div>
        <div class="col-sm-6">		
			<h2>Food & Beverages Products Delivery</h2>
			<p>Our approach is simple. Our routing tools and industry knowledge allow us to engineer distribution networks that exceed our customers' expectations. By helping to reduce miles and time, you'll get the benefit of delivering a fresher product.</p>
			<p>When you need to deliver the freshest food and beverage products daily, partner with the experts who know your business as well as you do.</p>
			<!-- <p>Currently SWIGY is one of the major client of us to whom we are providing services in Food & Beverages category</p> -->
			<p>From product pickup through delivery, DW Logistics provides:</p>
			<ul>
				<li>Flexible vendor pickups and just-in-time delivery</li>
				<li>An understanding of store and vendor requirements</li>
				<li>Delivery coordination between vendors, DC and stores</li>
				<li>Local sourcing of the freshest products</li>
			</ul>
			<p></p>		
			<p>
			<a href="tel:02249729022" class="btn btn-danger">Call: 022 4972 9022</a>
			<a href="mailto:info@ramkrishnahari.in" class="btn btn-danger">info@ramkrishnahari.in</a>
			<a href="contact.php" class="btn btn-danger">Write Us</a>
			</p>
			
		</div>
			
</div>
</div>
</section>

<section>	
<div class="container">	
<div class="row">	
        <div class="col-sm-12 text-center mb-4">
			<h2>Why you should collaborate with us?</h2>
			<p>Our personal experience with e-commerce and retail has enabled us to fill the major gaps in today's logistics landscape. Some of our best to-date feature launches have earned accolades for small & large customers in terms of revenue growth, increased customer satisfaction and retention. Businesses thrive when customers are serviceable and in-time.</p>
		</div>

			<div class="col-sm-4 text-center mb-4">
			<div class="border p-3 shadow-sm">
			<i class="fa fa-university fa-4x my-2"></i>
			<h4 class="font-20">Strong Background</h4>
			<p>Mumbai Dabbawala, we are well known across the world for our quality services, our dedication, our leadership and management style.</p>
			</div>
			</div>
			
			<div class="col-sm-4 text-center mb-4">
			<div class="border p-3 shadow-sm">
			<i class="fa fa-group fa-4x my-2"></i>
			<h4 class="font-20">Scalable & Flexible Resources</h4>
			<p>Do not worry to manage logistics because of your volume fluctuation. We are in capacity to manage resources as your business requires.</p>
			</div>
			</div>

			<div class="col-sm-4 text-center mb-4">
			<div class="border p-3 shadow-sm">
			<i class="fa fa-map-marker fa-4x my-2"></i>
			<h4 class="font-20">Area Coverages</h4>
			<p>Currently we are delivering services all over Maharashtra State and expanding our roots at Pan India Level. Connect with us from other states.</p>
			</div>
			</div>
			
			<div class="col-sm-4 text-center mb-4">
			<div class="border p-3 shadow-sm">
			<i class="fa fa-support fa-4x my-2"></i>
			<h4 class="font-20">Genuine Support</h4>
			<p>Our Team continuously monitors activities and are there to help you.</p>
			</div>
			</div>
			
			<div class="col-sm-4 text-center mb-4">
			<div class="border p-3 shadow-sm">
			<i class="fa fa-pie-chart fa-4x my-2"></i>
			<h4 class="font-20">Affordable Pricing</h4>
			<p>In this Expensive Market, we provide the best services and charge you the least.</p>
			</div>
			</div>

			<div class="col-sm-4 text-center mb-4">
			<div class="border p-3 shadow-sm">
			<i class="fa fa-clock-o fa-4x my-2"></i>
			<h4 class="font-20">Fast & Reliable Services</h4>
			<p>We are a Organized Unit which helps us to Work Faster and be Organized.</p>
			</div>
			</div>
			
			
</div>
</div>
</section>



<!-- Footer -->
<footer class="py-5">
<div class="container">
<div class="row">

    <div class="col-md-12 mb-4"> 
		<h4>Ramkrishnahari Enterprises</h4>
		<p class="font-14">D-601, Crystal Plaza, New Link Road, Andheri (W), Mumbai - 400053.</p>
		<a href="#" class="btn btn-outline-warning"><i class="fa fa-phone"></i> +91 022 4972 9022</a>
		<a href="#" class="btn btn-outline-warning"><i class="fa fa-envelope"></i> info@rkhenterprises.co.in</a>
    </div>

    <div class="col-md-12"> 
    <p class="m-0 font-14">Copyright &copy; 2020. All rights reserved.</a></p>
  </div>

</div>
</div>
</footer>


<!-- Bootstrap core JavaScript -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<!-- Bootstrap core JavaScript -->
<!--
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
-->
  <!-- Plugin JavaScript -->
<!--  <script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script> -->

  <!-- Custom JavaScript for this theme -->
  <script src="assets/js/scrolling-nav.js"></script>
  <script src="assets/data-hover/bootstrap-hover-dropdown.js"></script>
 
</body>
</html>

<!-- Button to Open the Modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Open modal</button> -->


<!-- The Modal -->
<div class="modal fade" id="AgentLogin">
  <div class="modal-dialog modal-md">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Vendor Login</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form method="post" action="vendor/index.php">
          <div class="form-group">
            <input type="email" name="inputEmail" class="form-control" placeholder="Email">
          </div>  
          <div class="form-group">
            <input type="password" name="inputPassword" class="form-control" placeholder="Password">
          </div>  
          <div class="form-group text-center">
            <input type="submit" name="vendorLogin" class="form-control btn btn-primary mb-3" value="Login"> 
            <a class="mt-4" href="get-started.php">Not Registered</a>
          </div>  
        </form>  
      </div>

      <!-- Modal footer -->
      <!--
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
      -->
    </div>
  </div>
</div>