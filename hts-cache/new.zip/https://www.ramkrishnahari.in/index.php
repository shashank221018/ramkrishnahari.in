<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="icon" type="image/png" href="assets/images/favicon.png">
  
  <title>Ramkrishnahari Enterprises</title>
  <meta name="description" content="Hare Rama Krishna Enterprises Logistic company.">
  
  <!-- Bootstrap core CSS -->
  <!-- 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  
  <!-- Custom styles for this template -->
  <link href="assets/css/scrolling-nav.css" rel="stylesheet">
  
</head>
<body id="page-top">  

<div class="sticky-top py-3 bg-orange text-white shadow-sm">
<div class="container text-center fw-600 font-25">Ramkrishnahari Enterprises</div>
</div>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-light static-top shadow-sm" id="mainNav">
<div class="container">
    <a class="navbar-brand js-scroll-trigger" href="index.php" id="logo">
	<!-- <h2 class="fw-600 text-dark">SVSS</h2> -->
    <img src="assets/images/ramkrishnahari-logo.jpg" alt="">
    </a>
	
    <button class="navbar-toggler bg-secondary1 mr-2" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
    <span class="fa fa-bars"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">
    <ul class="navbar-nav ml-auto">

      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="about.php">About Us</a>
      </li>

		<li class="nav-item dropdown">
		  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		  Services</a>
			 <div class="dropdown-menu dropdown-menu-left text-left" aria-labelledby="navbarDropdown">
			 <a class="dropdown-item" href="ecommerce-products.php">Delivery of E-Commerce Products</a>
			 <a class="dropdown-item" href="grocery-products.php">Delivery of Grocery Products</a>
			 <a class="dropdown-item" href="food-beverage-products.php">Delivery of Food & Beverage Products</a>
			 <a class="dropdown-item" href="tiffin-suppliers.php">Tiffin Suppliers</a>
			 <a class="dropdown-item" href="customized-delivery.php">Customized Delivery Services</a>
			 </div>
		</li>

      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="career.php">Career</a>
      </li>
      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="job-request.php">Apply for Job</a>
      </li>
      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="contact.php">Contact Us</a>
      </li>
          
	</ul>	
    </div>	  	  

</div>
</nav><div id="myCarousel" class="carousel slide" data-ride="carousel">
	<ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>
  
	<div class="carousel-inner">
		<!--
		<div class="carousel-item active">
            <img class="first-slide" src="assets/slider/slide4.jpg" alt="">
            <div class="container">
              <div class="carousel-caption">
                <h2 class="text-uppercase caption-left font-50 text-shadow">Slider Caption 1</h2>
              </div>
            </div>
        </div>
		-->
        <div class="carousel-item active">
			<img src="assets/slider/slider4.jpg" alt="">
        </div>		
        <div class="carousel-item">
			<img src="assets/slider/slider1.jpg" alt="">
        </div>		
        <div class="carousel-item">
			<img src="assets/slider/slider2.jpg" alt="">
        </div>
        <div class="carousel-item">
			<img src="assets/slider/slider3.jpg" alt="">
        </div>	
    </div>
<!--		
    <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
-->		
</div>
<!-- Page Content -->
<section class="bg-orange py-4">
<div class="container border shadow py-4 bg-white">		
<div class="row">
	<div class="col-md-3 col-3">
	<img src="assets/images/logistic-service-1.png" class="img-fluid">
	</div>	
	<div class="col-md-9 col-9">
	<h1>Welcome to Ramkrishnahari Enterprises</h1>
	<p>Ramkrishnahari Enterprises has 15 Years experience in supply-chain of groceries logistics, traditional logistics E-Commerce logistics, door to door parcel delivery service, home delivery of food & beverages products, Tiffin suppliers and all kinds product deliveries as per requirement of client.</p>
	<p>Our team's e-commerce roots have equipped us with in-depth knowledge about the operational and logistics requirement in the fast-paced e-commerce industry. Our service industry background defines our customer first approach.</p>
	</div>		
</div>
</div>
</section>

	
<section>
<div class="container">	
<div class="row">

	<div class="col-md-12 text-center mb-4"> 
		<h2>What We Do?</h2>
	</div>
		
	<div class="col-md-4">
		<div class="card">
		<img src="assets/images/ecommerce-products.jpg" class="card-img-top">
		<div class="card-body">
		<h4 class="card-title font-20">E-Commerce Products Delivery</h4>
		<p>We are preferred partner with of top brands in India. We helps E-Commerce businesses to deliver products at consumer door step so you dont have to invest in infrastructure and team.</p>
		<a href="ecommerce-products.php" class="btn btn-primary">Read More</a>
		</div>
		</div>
	</div>		

	<div class="col-md-4">
		<div class="card">
		<img src="assets/images/grocery-products.jpg" class="card-img-top">
		<div class="card-body">
		<h4 class="card-title font-20">Grocery Products Delivery</h4>
		<p>There is new trend ordering grocery products online. Most of the businesses are successful but there are many who doesnt because of logistic support. We help you to grow.</p>
		<a href="grocery-products.php" class="btn btn-primary">Read More</a>
		</div>
		</div>
	</div>		
	
	<div class="col-md-4">
		<div class="card">
		<img src="assets/images/food-products.jpg" class="card-img-top">
		<div class="card-body">
		<h4 class="card-title font-20">Food Products Delivery</h4>
		<p>Along with Grocery products another segment which is highly in demand is Online Food Ordering. We help our customers to deliver there products on time at consumer door steps.</p>
		<a href="food-beverage-products.php" class="btn btn-primary">Read More</a>
		</div>
		</div>
	</div>		
		
</div>
</div>	
</section>	

<div class="clearfix"></div>



<!-- /section .container -->
	


<!-- Footer -->
<footer class="py-5">
<div class="container">
<div class="row">

    <div class="col-md-12 mb-4"> 
		<h4>Ramkrishnahari Enterprises</h4>
		<p class="font-14">D-601, Crystal Plaza, New Link Road, Andheri (W), Mumbai - 400053.</p>
		<a href="#" class="btn btn-outline-warning"><i class="fa fa-phone"></i> +91 022 4972 9022</a>
		<a href="#" class="btn btn-outline-warning"><i class="fa fa-envelope"></i> info@rkhenterprises.co.in</a>
    </div>

    <div class="col-md-12"> 
    <p class="m-0 font-14">Copyright &copy; 2020. All rights reserved.</a></p>
  </div>

</div>
</div>
</footer>


<!-- Bootstrap core JavaScript -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<!-- Bootstrap core JavaScript -->
<!--
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
-->
  <!-- Plugin JavaScript -->
<!--  <script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script> -->

  <!-- Custom JavaScript for this theme -->
  <script src="assets/js/scrolling-nav.js"></script>
  <script src="assets/data-hover/bootstrap-hover-dropdown.js"></script>
 
</body>
</html>

<!-- Button to Open the Modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Open modal</button> -->


<!-- The Modal -->
<div class="modal fade" id="AgentLogin">
  <div class="modal-dialog modal-md">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Vendor Login</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form method="post" action="vendor/index.php">
          <div class="form-group">
            <input type="email" name="inputEmail" class="form-control" placeholder="Email">
          </div>  
          <div class="form-group">
            <input type="password" name="inputPassword" class="form-control" placeholder="Password">
          </div>  
          <div class="form-group text-center">
            <input type="submit" name="vendorLogin" class="form-control btn btn-primary mb-3" value="Login"> 
            <a class="mt-4" href="get-started.php">Not Registered</a>
          </div>  
        </form>  
      </div>

      <!-- Modal footer -->
      <!--
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
      -->
    </div>
  </div>
</div>